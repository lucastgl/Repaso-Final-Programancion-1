"""

Crear una función que elimine los elementos de una lista que tenga
determinado valor

"""